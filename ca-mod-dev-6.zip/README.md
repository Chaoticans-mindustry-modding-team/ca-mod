# ca-mod
The purpose of this mod is to expand roleplays, add QoL (Quality of Life) changes, and to improve the sandbox experience.
## Features
- More walls!
- Roleplaying blocks like lanterns, chains, cups, vials, cobweb, anvils, and crystals!
- Infinite messages!
- Customizable sorter walls!
- Chiseled and decorated blocks!
- Spectral blocks!
- Larger blocks!
- Ultra micro processor!
- Items as blocks!
- Latum/Renale spawner! (no need logic blocks)
- Bigger canvases!
- Borderless blocks!
- Colored blocks!
- Smaller blocks!
- 32x32 Canvas! (replicanvas)
- Reality projector!
- Sound blocks!
- Infinite bridges!
- Borderless liquid container! (can be used to add gradients)

# ca-mod
The purpose of this mod is to expand the sandbox content, adding a shitload for RPs.
## Features
- More walls
- Blocks for detailing
- Infinite messages
- Customizable sorter walls
- Chiseled stuff
- Spectral blocks
- Larger blocks
- Omega processor & Omega memory cell
- Revamped canvases
- Borderless blocks
- Colored blocks
- Smaller blocks
- Reality projector!
- Sound blocks
- Infinite bridges
- Borderless liquid container (can be used to add gradients)
